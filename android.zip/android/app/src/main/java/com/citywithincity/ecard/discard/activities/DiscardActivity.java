package com.citywithincity.ecard.discard.activities;

import android.os.Bundle;

import com.citywithincity.ecard.R;
import com.damai.auto.DMFragmentActivity;


/**
 * 
 * @author renxueliang
 *
 */
public class DiscardActivity extends DMFragmentActivity {
	protected void onSetContent(Bundle savedInstanceState) {
		setContentView(R.layout.activity_discard);
	}

}
