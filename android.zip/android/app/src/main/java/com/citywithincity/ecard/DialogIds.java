package com.citywithincity.ecard;

public class DialogIds {
	public static final int DIY = 1;
	
	public static final int E_CHANNEL = DIY + 1;
	public static final int DUDUBAO_CHANNEL = E_CHANNEL+1;
	public static final int TIANYU_CHANNEL = DUDUBAO_CHANNEL+1;
}
