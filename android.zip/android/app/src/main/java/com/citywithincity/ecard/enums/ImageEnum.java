package com.citywithincity.ecard.enums;

public class ImageEnum {

	public static final int IMAGE_WIDTH = 1016;
	public static final int IMAGE_HEIGHT = 638;
	public static final int RADIYRAT= 40;
	
	public static final int SMALL_IMAGE_WIDTH = 264;
	public static final int SMALL_IMAGE_HEIGHT = 162;
	public static final int SMALL_RADIYRAT= 20;
}
