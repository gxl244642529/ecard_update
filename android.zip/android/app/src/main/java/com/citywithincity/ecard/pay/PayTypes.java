package com.citywithincity.ecard.pay;

public class PayTypes {
	public static final int PayType_Alipay = 1;
	public static final int PayType_Weixin = 2;
	public static final int PayType_ECard = 3;
	public static final int PayType_CMB = 5;
	public static final int PayType_UMA = 6;
}
