/**
 * 
 */
/**
 * @author admin
 *
 */
package com.citywithincity.ecard.recharge.models.vos;