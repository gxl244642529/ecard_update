package com.citywithincity.ecard.pay;

public class PayIds {
	// 预约s
	public static final int PAY_ID_BOOK = 1;
	//充值
	public static final int PAY_ID_RECHARGE = 2;
	//保险
	public static final int PAY_ID_PICC = 3;
	//自行车
	public static final int PAY_ID_BICYCLE = 4;
}
