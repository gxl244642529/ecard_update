/**
 * 
 */
/**
 * @author randy
 *
 */
package com.citywithincity.ecard.models.vos;