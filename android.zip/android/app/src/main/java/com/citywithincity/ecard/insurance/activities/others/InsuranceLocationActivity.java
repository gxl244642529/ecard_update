package com.citywithincity.ecard.insurance.activities.others;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.citywithincity.ecard.R;
import com.citywithincity.interfaces.IOnItemClickListener;
import com.citywithincity.utils.Alert;
import com.citywithincity.widget.StateListView;
import com.damai.auto.DMActivity;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;

import java.util.ArrayList;
import java.util.List;

public class InsuranceLocationActivity extends DMActivity {
	


	@SuppressWarnings("unchecked")
	@Override
	protected void onSetContent(Bundle savedInstanceState) {
		setContentView(R.layout.activity_insurance_location);
		

		
	}
	


}
