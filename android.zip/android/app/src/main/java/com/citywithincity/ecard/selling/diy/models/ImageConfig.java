package com.citywithincity.ecard.selling.diy.models;

public class ImageConfig {

	public static final int IMAGE_WIDTH = 1016;
	public static final int IMAGE_HEIGHT = 638;
	
	
	
	public static final int PAGE_IMAGE_WIDTH = 640;
	public static final int PAGE_IMAGE_HEIGHT = 480;
	public static final int HEAD_IMAGE_SIZE = 350;
}
