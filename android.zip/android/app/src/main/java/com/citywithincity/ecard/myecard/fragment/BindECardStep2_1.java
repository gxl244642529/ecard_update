package com.citywithincity.ecard.myecard.fragment;


public class BindECardStep2_1 extends BindECardStep2_2 {


}
