package com.citywithincity.ecard.selling.activities;

import android.os.Bundle;

import com.citywithincity.activities.BaseActivity;


/**
 * diy编辑器
 * @author randy
 *
 */
public class SDiyEditorActivity extends BaseActivity {

	@Override
	protected void onSetContent(Bundle savedInstanceState) {
		// TODO Auto-generated method stub

	}

}
