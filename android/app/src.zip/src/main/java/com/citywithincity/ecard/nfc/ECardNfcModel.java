package com.citywithincity.ecard.nfc;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.tech.IsoDep;
import android.nfc.tech.TagTechnology;

import com.citywithincity.interfaces.IViewContainer;
import com.damai.core.ILife;
import com.jzoom.nfc.DepTagAdapter;
import com.jzoom.nfc.NfcException;
import com.jzoom.nfc.NfcListener;
import com.jzoom.nfc.NfcModel;
import com.jzoom.nfc.impl.CpuCard;
import com.jzoom.nfc.impl.IsoDepTagAdapter;

import java.io.IOException;

/**
 * Created by renxueliang on 2017/10/20.
 */

public class ECardNfcModel extends NfcModel implements NfcListener,ILife {


    protected DepTagAdapter adapter;

    private NfcListener listener;

    private CpuCard cpuCard = new CpuCard();

    public ECardNfcModel(Activity activity) throws IntentFilter.MalformedMimeTypeException {
        super(activity, IsoDep.class);
        if(activity instanceof IViewContainer){
            ((IViewContainer)activity).addLife(this);
        }
        super.setListener(this);
    }


    @Override
    public void setListener(NfcListener listener) {
        this.listener = listener;
    }

    private CardReader cardReader;



    @Override
    public void onNfcEvent(TagTechnology tag) {
        if(adapter!=null){
            adapter.close();
        }
        if(tag instanceof  IsoDep){
            adapter = new IsoDepTagAdapter( (IsoDep)tag);
            //通知感知到了
            try {
                adapter.connect();
                cardReader=selectFile();
                listener.onNfcEvent(tag);
            } catch (IOException e) {

            } catch (NfcException e) {

            }

        }
    }

    private CardReader selectFile() throws IOException, NfcException {
        try{
            //交通不卡
            cpuCard.selectFile(adapter, "00A4040008A000000632010105");
            return new TransCardReader();
        }catch (NfcException e){
            //cpu卡
            cpuCard.selectFile(adapter, "00a40000023f00");
            return new CpuCardReader();
        }
    }


    public String getCardId() throws IOException, NfcException {
        if(cardReader==null || adapter==null){
            throw new IOException();
        }
        return cardReader.getCardId(cpuCard,adapter);
    }


    /**
     *
     * @return
     * @throws IOException
     * @throws NfcException
     */
    public CardReader.ChargeInfo getOtherRechargeInfo() throws IOException, NfcException {
        if(cardReader==null || adapter==null){
            throw new IOException();
        }
        //0015
        return cardReader.getOtherRechargeInfo(cpuCard,adapter);

    }



    public void close() {
        if(adapter!=null){
            adapter.close();
        }
    }



    public String apdu(String apdu) throws IOException, NfcException {
        if(adapter!=null){
            return adapter.send(apdu).getStr();
        }
        throw new IOException();
    }

    @Override
    public void onResume(IViewContainer iViewContainer) {
        onResume(iViewContainer.getActivity());
    }

    @Override
    public void onPause(IViewContainer iViewContainer) {
        onPause(iViewContainer.getActivity());
    }

    @Override
    public void onNewIntent(Intent intent, IViewContainer iViewContainer) {
        onNewIntent(intent);
    }

    @Override
    public void onDestroy(IViewContainer iViewContainer) {
        destroy();
    }

    public NfcResult getCardInfo() throws IOException, NfcException {

       return cardReader.getAll(cpuCard,adapter);





    }
}
