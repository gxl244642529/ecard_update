/**
 * 
 */
/**
 * @author renxueliang
 *
 */
package com.citywithincity.ecard.myecard.activities;