/**
 * 
 */
/**
 * @author admin
 *
 */
package com.citywithincity.ecard.insurance.models.vos;