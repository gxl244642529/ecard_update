/**
 * 
 */
/**
 * @author admin
 *
 */
package com.citywithincity.ecard.insurance.widgets;