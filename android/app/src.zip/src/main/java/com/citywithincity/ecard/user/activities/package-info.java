/**
 * 
 */
/**
 * @author renxueliang
 *
 */
package com.citywithincity.ecard.user.activities;