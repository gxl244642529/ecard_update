package com.citywithincity.ecard.react;

import android.app.Activity;
import android.content.IntentFilter;
import android.nfc.tech.TagTechnology;
import android.support.annotation.Nullable;

import com.citywithincity.ecard.models.TianYu;
import com.citywithincity.ecard.nfc.NfcDialog;
import com.citywithincity.ecard.nfc.NfcResult;
import com.citywithincity.ecard.nfc.ECardNfcModel;
import com.citywithincity.ecard.utils.NfcUtil;
import com.citywithincity.interfaces.DialogListener;
import com.citywithincity.utils.Alert;
import com.damai.auto.LifeManager;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.jzoom.nfc.NfcException;

import java.io.IOException;


/**
 * Created by renxueliang on 17/3/21.
 */

public class NfcModule extends ReactContextBaseJavaModule implements   com.jzoom.nfc.NfcListener {



    public static final String CPU = "cpu";

    protected ECardNfcModel model;

    public NfcModule(ReactApplicationContext reactContext) {
        super(reactContext);
        try {
            model = new ECardNfcModel(LifeManager.getActivity());
            model.setListener(this);
        } catch (IntentFilter.MalformedMimeTypeException e) {

        }


    }

    @Override
    public String getName() {
        return "NfcModule";
    }


    @ReactMethod
    public void close(){
        if(model!=null){
            model.close();
        }
    }


    @ReactMethod
    public void isAvailable(Callback callback){
        callback.invoke(NfcUtil.isAvailable(getCurrentActivity()));
    }


    /*
    @ReactMethod
    public void adpu(ReadableArray command, Promise promise){
        if(adapter==null){
            promise.reject("io","closed");
            return;
        }
        try {
            adapter.connect();
            WritableArray arr = Arguments.createArray();
            for(int i=0 , c = command.size(); i < c; ++i){
                try{
                    String cmd = command.getString(i);
                    if(cmd.contains(",")){
                        String[] args = cmd.split(",");
                        NfcResponse response = null;
                        for(String arg : args){
                            response = adapter.send(arg);
                        }
                        //只用最后一个为主
                        String result = response.getStr();
                        arr.pushString(result);
                    }else{
                        NfcResponse response = adapter.send(command.getString(i));
                        String result = response.getStr();
                        arr.pushString(result);
                    }
                }catch (IOException e){
                    promise.reject("io",e);
                    return;
                }catch (NfcException e){
                    promise.reject("nfc",e);
                    return;
                }
            }
            promise.resolve(arr);
        } catch (IOException e) {
            promise.reject("io",e);
        }
    }

*/


    @Override
    public void onNfcEvent(TagTechnology tag) {

        notifyEvent("nfcTag", Arguments.createMap());

    }

    protected void notifyEvent(String eventName,@Nullable Object data){
        getReactApplicationContext().getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(eventName,data);
    }

    private NfcDialog nfcDialog;



    @ReactMethod
    public void handleSelf(){
        if(nfcDialog!=null){
            return;
        }
        try {
            NfcResult result = model.getCardInfo();
            nfcDialog = new NfcDialog(getCurrentActivity(), new DialogListener() {
                @Override
                public void onDialogButton(int i) {
                    nfcDialog = null;
                }
            });
            nfcDialog.onNecReaded(result);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NfcException e) {
            e.printStackTrace();
        } finally {
            model.close();
        }

        /*
        TagAdapter adapter = null;
        final IsoDep isodep = IsoDep.get(tag);
        try{
            adapter = new TagAdapter(isodep);
            adapter.connect();
            INfcReader reader = new XmECardReader();
            NfcResult result = reader.read(adapter,  INfcReader.MODE_HISTORY);
            nfcDialog = new NfcDialog(getCurrentActivity(), new DialogListener() {
                @Override
                public void onDialogButton(int i) {
                    nfcDialog = null;
                }
            });
            nfcDialog.onNecReaded(result);
        }catch(Exception e){

        }finally{
            if(adapter!=null){
                adapter.close();
            }
        }*/

    }



    @ReactMethod
    public void readCard(Callback callback){
        if(model!=null){
            try {
                callback.invoke(model.getCardId());
            }  catch (IOException e) {
                Alert.showShortToast("请重新贴卡");
            } catch (NfcException e) {
                Alert.showShortToast("请重新贴卡");
            }
        }else{
            callback.invoke("");
        }

        /*
        TagAdapter adapter = null;
        final IsoDep isodep = IsoDep.get(tag);
        try{
            adapter = new TagAdapter(isodep);
            adapter.connect();
            INfcReader reader = new XmECardReader();
            NfcResult result = reader.read(adapter,  INfcReader.MODE_HISTORY);
            callback.invoke(result.getCardId());
        }catch(Exception e){

        }finally{
            if(adapter!=null){
                adapter.close();
            }
        }*/
    }


    @ReactMethod
    public void recharge(String tyId,String cardId,int fee,String acc){
        Activity ac= getCurrentActivity();
        if (NfcUtil.isAvailable(ac)) {
            TianYu.startRecharge(ac,
                    acc,
                    cardId,
                    tyId, fee,false);
        } else {
            Alert.showShortToast("本手机不支持nfc设备");
        }
    }



}
