/**
 * 
 */
/**
 * @author renxueliang
 *
 */
package com.citywithincity.ecard.widget;