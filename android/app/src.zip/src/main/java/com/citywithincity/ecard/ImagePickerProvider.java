package com.citywithincity.ecard;

import android.support.v4.content.FileProvider;

/**
 * Created by renxueliang on 17/4/11.
 */

public class ImagePickerProvider extends FileProvider {


}
