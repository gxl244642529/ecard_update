package com.citywithincity.ecard.ui.activity;

import com.damai.auto.DMWebActivity;

public class PushActivity extends DMWebActivity {
	
}
