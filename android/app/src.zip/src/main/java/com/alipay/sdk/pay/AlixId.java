/*
 * Copyright (C) 2010 The MobileSecurePay Project
 * All right reserved.
 * author: shiqun.shi@alipay.com
 */

package com.alipay.sdk.pay;

public final class AlixId
{
	public static final int BASE_ID 			= 0;
	public static final int RQF_PAY 			= BASE_ID + 1;
	public static final int RQF_INSTALL_CHECK = RQF_PAY + 1;
}
