package com.damai.nfc;

/**
 * Created by randy on 2017/1/28.
 */

public class NfcReader implements NfcListener {


    @Override
    public boolean onNfcEvent(NfcTagAdapter adapter) {
        return true;
    }
}
