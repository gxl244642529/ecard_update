package com.damai.nfc;

import java.util.Arrays;

/**
 * Created by randy on 2017/1/27.
 */

public class NfcResponse {

    public static final short VALID_VALUE = (short)0x0090;

    public static final NfcResponse OK = new NfcResponse(new byte[]{ (byte)0x90,(byte)0x00 });

    private byte[] src;
    public NfcResponse(byte[] src){
        this.src = src;
    }

    public byte[] getData(){
        return Arrays.copyOf(src,src.length-2);
    }

    public String getStr(){
        return HexUtil.encodeHexStr(src,src.length-2);
    }

    public boolean isOk(){
        return getSw() == VALID_VALUE;
    }

    public short getSw(){
        return HexUtil.toShort(src,src.length-2);
    }

    public NfcResponse validate() throws NfcException {
        short sw = getSw();
        if(sw != VALID_VALUE){
            throw new NfcException(sw);
        }
        return this;
    }

    public byte[] getRowData() {
        return src;
    }
}
