package com.damai.nfc.impl;

import com.damai.nfc.HexUtil;
import com.damai.nfc.NfcException;
import com.damai.nfc.NfcResponse;
import com.damai.nfc.NfcTagAdapter;
import com.damai.nfc.PbocCard;
import com.damai.nfc.vos.CardTradeVo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by renxueliang on 2017/10/19.
 */

public class CpuCard implements PbocCard {
    public final static byte TRANS_CSU = 6;
    public final static byte TRANS_CSU_CPX = 9;

    @Override
    public void selectFile(NfcTagAdapter adapter, String file) throws IOException, NfcException {
        String apdu = String.format("00a40000%02x%s",file.length()/2,file);
        adapter.send(apdu);
    }


    @Override
    public String getFile(NfcTagAdapter adapter,int sfi) throws IOException, NfcException {
        //00b0850000
        String apdu = String.format("00b0%02x0000",  0x80 | sfi );
        NfcResponse response = adapter.send(apdu);
        return response.getStr();
    }


    @Override
    public int getBalance(NfcTagAdapter adapter) throws IOException, NfcException {
        NfcResponse response = adapter.send("805C000204");
        int value = Integer.parseInt(response.getStr(),16);
        return value;
    }

    @Override
    public List<CardTradeVo> getTradeLogs(NfcTagAdapter adapter) throws IOException, NfcException {
        List<CardTradeVo> result = new ArrayList<CardTradeVo>();
        for(int i=1; i <= 10; ++i){
            try{
                NfcResponse response = adapter.send(String.format("00b2%sc400", HexUtil.int2HexStr(i,2)));
                byte[] v = response.getRowData();
                int cash = HexUtil.toInt(v, 5,4);
                if(cash>0){
                    CardTradeVo vo = new CardTradeVo();
                    vo.setTime(String.format("%02X%02X.%02X.%02X %02X:%02X ",
                            v[16], v[17], v[18], v[19], v[20], v[21], v[22]));

                    vo.setType((v[9] == TRANS_CSU || v[9] == TRANS_CSU_CPX) ? CardTradeVo.TYPE_SUB
                            : CardTradeVo.TYPE_ADD);

                    vo.setCash(String.format("%.02f",(float)cash/100));
                    result.add(vo);
                }
            }catch (NfcException e){
                break;
            }
        }
        return result;
    }
}
