package com.damai.nfc;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.os.Build;
import android.os.Parcelable;

import com.citywithincity.interfaces.IViewContainer;
import com.damai.core.ILife;
import com.damai.nfc.impl.IsoDepTagAdapter;

import java.io.IOException;

/**
 * Created by randy on 2017/1/28.
 */

/**
 * nfc的运行环境
 */
public class NfcContext implements ILife {
    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;

    public static String[][] TECHLISTS;
    public static IntentFilter[] FILTERS;



    static {
        try {
            TECHLISTS = new String[][] { { IsoDep.class.getName() } };

            FILTERS = new IntentFilter[] { new IntentFilter(
                    NfcAdapter.ACTION_TECH_DISCOVERED, "*/*") };
        } catch (Exception e) {

        }
    }


    private NfcListener listener;





    public NfcContext(IViewContainer c) {
        Activity activity = c.getActivity();
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD_MR1) {
            nfcAdapter = NfcAdapter.getDefaultAdapter(activity);
            pendingIntent = PendingIntent.getActivity(activity, 0, new Intent(
                    activity, activity.getClass())
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
            c.addLife(this);
            onNewIntent(activity.getIntent(),c);
        }
    }


    @Override
    public void onResume(IViewContainer container) {
        if (nfcAdapter != null) {
            nfcAdapter.enableForegroundDispatch(container.getActivity(), pendingIntent,FILTERS, TECHLISTS);
        }
    }

    @Override
    public void onPause(IViewContainer container) {
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(container.getActivity());
        }
    }

    @Override
    public void onNewIntent(Intent intent, IViewContainer container) {
        Parcelable p = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (p != null) {
            load(p);
        }
    }

    private void load(Parcelable parcelable) {
        final Tag tag = (Tag) parcelable;
        final IsoDep isodep = IsoDep.get(tag);
        IsoDepTagAdapter adapter = new IsoDepTagAdapter(isodep);
        boolean close = false;
        try {
            adapter.connect();
            //进行加载
            if(listener!=null){
                close = listener.onNfcEvent(adapter);
            }
            //IllegalStateException
        } catch (IllegalStateException e){
            e.printStackTrace();
        } catch(IOException e) {
            e.printStackTrace();
        }finally {
            if(close){try { adapter.close();} catch (Throwable e) { }}
        }

    }

    @Override
    public void onDestroy(IViewContainer container) {
        listener = null;
    }

    public NfcListener getListener() {
        return listener;
    }

    public void setListener(NfcListener listener) {
        this.listener = listener;
    }
}
