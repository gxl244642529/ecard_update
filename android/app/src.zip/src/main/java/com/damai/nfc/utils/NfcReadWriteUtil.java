package com.damai.nfc.utils;

import android.content.Intent;

import com.damai.nfc.HexUtil;
import com.damai.nfc.NfcException;
import com.damai.nfc.NfcResponse;
import com.damai.nfc.NfcTagAdapter;
import com.damai.nfc.vos.CardTradeVo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Created by randy on 2017/1/28.
 */

public class NfcReadWriteUtil {

    /**
     * 获取卡片余额
     * @param adapter
     * @param fileApdu
     * @return
     * @throws IOException
     * @throws NfcException
     */
    public static String getFormatBalance(NfcTagAdapter adapter,String fileApdu) throws IOException, NfcException {
        return String.format("%.02f",(float)getBalance(adapter,fileApdu)/100);
    }

    /**
     * 获取余额（单位为分)
     * @param adapter
     * @param fileApdu
     * @return
     * @throws IOException
     * @throws NfcException
     */
    public static int getBalance(NfcTagAdapter adapter,String fileApdu) throws IOException, NfcException {
        adapter.send(fileApdu);
        NfcResponse response = adapter.send("805C000204");
        int value = Integer.parseInt(response.getStr(),16);
        return value;
    }

    public static String getFile0005(NfcTagAdapter adapter, String fileApdu) throws IOException, NfcException {
        adapter.send(fileApdu);
        NfcResponse response = adapter.send("00b0850000");
        return response.getStr();
    }

    public static String getFile0015(NfcTagAdapter adapter, String fileApdu) throws IOException, NfcException {
        adapter.send(fileApdu);
        NfcResponse response = adapter.send("00b0950000");
        return response.getStr();
    }
    public final static byte TRANS_CSU = 6;
    public final static byte TRANS_CSU_CPX = 9;
    public static List<CardTradeVo> getLogs(NfcTagAdapter adapter, String fileApdu) throws IOException, NfcException {
        adapter.send(fileApdu);


        List<CardTradeVo> result = new ArrayList<CardTradeVo>();
        for(int i=1; i <= 10; ++i){
            try{
                NfcResponse response = adapter.send(String.format("00b2%sc400", HexUtil.int2HexStr(i,2)));
                byte[] v = response.getRowData();
                int cash = HexUtil.toInt(v, 5,4);
                if(cash>0){
                    CardTradeVo vo = new CardTradeVo();
                    vo.setTime(String.format("%02X%02X.%02X.%02X %02X:%02X ",
                            v[16], v[17], v[18], v[19], v[20], v[21], v[22]));

                    vo.setType((v[9] == TRANS_CSU || v[9] == TRANS_CSU_CPX) ? CardTradeVo.TYPE_SUB
                            : CardTradeVo.TYPE_ADD);

                    vo.setCash(String.format("%.02f",(float)cash/100));
                    result.add(vo);
                }
            }catch (NfcException e){
                break;
            }
        }
        return result;
    }




    public static String getFile8050(NfcTagAdapter adapter,String adpu) throws IOException, NfcException{
        NfcResponse response = adapter.send(adpu);
        return response.getStr();
    }

    /**
     * 检查记录有没有成功，只有返回的情况下才能判断是否有成功，如果抛出错误，则应该提示重新贴卡
     * @param adapter
     * @param fileApdu
     * @param nextTransIndex
     * @return
     * @throws IOException
     * @throws NfcException
     */
    public static boolean check(NfcTagAdapter adapter, String fileApdu,String nextTransIndex) throws IOException, NfcException {
        adapter.send(fileApdu);
        String adpu = String.format("805a00%s02%s08", "02" ,nextTransIndex);
        try{
            adapter.send(adpu);
            return true;
        }catch (NfcException e){
            return false;
        }

    }
}
