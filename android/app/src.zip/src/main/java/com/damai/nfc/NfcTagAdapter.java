package com.damai.nfc;

import java.io.IOException;

/**
 * Created by randy on 2017/1/28.
 */

public interface NfcTagAdapter {
    /**
     * 发送指令，并返回数据
     * @param adpu
     * @return
     */
    NfcResponse send(String adpu) throws IOException,NfcException;

    void connect() throws IOException;

    void close();

    boolean isConnected();
}
