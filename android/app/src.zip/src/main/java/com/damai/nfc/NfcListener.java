package com.damai.nfc;

/**
 * Created by randy on 2017/1/28.
 */

public interface NfcListener {
    /**
     * 贴卡
     * @param adapter
     */
    boolean onNfcEvent(NfcTagAdapter adapter);
}
