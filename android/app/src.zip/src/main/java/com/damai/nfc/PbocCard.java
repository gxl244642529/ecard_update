package com.damai.nfc;

import com.damai.nfc.vos.CardTradeVo;

import java.io.IOException;
import java.util.List;

/**
 * Created by renxueliang on 2017/10/19.
 */

public interface PbocCard {

    /**
     * 选择文件
     * @param file          文件标志
     * @throws IOException
     * @throws NfcException
     */
    void selectFile(NfcTagAdapter adapter,String file) throws IOException,NfcException;

    /**
     * 获取文件
     * @param sfi   短文件标志
     * @return
     * @throws IOException
     * @throws NfcException
     */
    String getFile(NfcTagAdapter adapter,int sfi) throws  IOException,NfcException;

    /**
     * 读取余额
     * @return
     */
    int getBalance(NfcTagAdapter adapter) throws  IOException,NfcException;


    /**
     * 读取交易记录
     * @return
     * @throws IOException
     * @throws NfcException
     */
    List<CardTradeVo> getTradeLogs(NfcTagAdapter adapter) throws  IOException,NfcException;
}
