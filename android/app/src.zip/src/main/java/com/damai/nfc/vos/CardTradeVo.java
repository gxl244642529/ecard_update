package com.damai.nfc.vos;

/**
 * Created by randy on 2017/1/28.
 */

public class CardTradeVo {
    /**
     *
     */
    private static final long serialVersionUID = -5116026592278369465L;


    public static final int TYPE_ADD = 1;
    public static final int TYPE_SUB = 0;


    public String getTypeStr(){
        return getType()==1 ? "充值" : "支付";
    }



    public int getType() {
        return type;
    }
    public void setType(int type) {
        this.type = type;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCash() {
        return cash;
    }

    public void setCash(String cash) {
        this.cash = cash;
    }

    private int type;
    //交易时间
    private String time;
    //交易金额
    private String cash;
}
