package com.damai.nfc.impl;

import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.nfc.tech.TagTechnology;

import com.damai.nfc.HexUtil;
import com.damai.nfc.NfcException;
import com.damai.nfc.NfcResponse;
import com.damai.nfc.NfcTagAdapter;

import java.io.IOException;

/**
 * Created by randy on 2017/1/28.
 */

public class IsoDepTagAdapter implements NfcTagAdapter {

    private IsoDep isoDep;

    /**
     * 当前文件
     */
    private String currentFile;

    public IsoDepTagAdapter(IsoDep isoDep){
        this.isoDep = isoDep;
    }



    @Override
    public NfcResponse send(String adpu) throws IOException, NfcException {
        try{
            return new NfcResponse(isoDep.transceive(HexUtil.decodeHex(adpu))).validate();
        }catch (NfcException e){
            reset();
            throw  e;
        }catch (IOException e){
            reset();
            throw  e;
        }

    }

    private void tryReconnect(){
        close();
        try{
            isoDep.connect();
        }catch (IOException e){
            reset();
        }

    }

    private void reset() {
        currentFile = null;
    }

    @Override
    public void connect() throws IOException {
        if(!isoDep.isConnected()){
            isoDep.connect();
        }
    }

    public void close(){
        reset();
        try {
            isoDep.close();
        } catch (Throwable e) {

        }
    }


    public boolean isConnected() {
        return isoDep.isConnected();

    }
}
