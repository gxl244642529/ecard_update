package com.damai.nfc.utils;

/**
 * Created by randy on 2017/1/28.
 */

import com.damai.nfc.NfcException;
import com.damai.nfc.NfcTagAdapter;
import com.damai.nfc.vos.CardTradeVo;

import java.io.IOException;
import java.util.List;

/**
 * 16位cup卡
 */
public class CpuCard16 {


    public static String getFormatBalance(NfcTagAdapter adapter) throws IOException, NfcException{
        return NfcReadWriteUtil.getFormatBalance(adapter,"00a40000023f01");
    }

    public static String getCardId(String file0005){
        return file0005.substring(40,56);
    }

    public static int getBalance(NfcTagAdapter adapter) throws IOException, NfcException{
        return NfcReadWriteUtil.getBalance(adapter,"00a40000023f01");
    }

    public static String  getFile0005(NfcTagAdapter adapter) throws IOException, NfcException{
        return NfcReadWriteUtil.getFile0005(adapter,"00a40000023f00");
    }

    public static String  getFile0015(NfcTagAdapter adapter) throws IOException, NfcException{
        return NfcReadWriteUtil.getFile0015(adapter,"00a40000023f01");
    }

    public static String getCardId(NfcTagAdapter adapter) throws IOException, NfcException {
        return getCardId(getFile0005(adapter));
    }

    /**
     *
     * @param adapter
     * @param nextTransIndex
     * @return
     * @throws IOException
     * @throws NfcException
     */
    public static boolean check(NfcTagAdapter adapter,String nextTransIndex) throws IOException, NfcException {
        return NfcReadWriteUtil.check(adapter,"00a40000023f01",nextTransIndex);
    }

    /**
     * 随机数
     * @return
     */
    public static String getRandom(NfcTagAdapter adapter) throws IOException, NfcException {
        return adapter.send("0084000004").getStr();
    }

    //A000000632010105
    public static List<CardTradeVo> getLogs(NfcTagAdapter adapter) throws IOException, NfcException {
        return NfcReadWriteUtil.getLogs(adapter,"00a40000023f01");
    }

}
