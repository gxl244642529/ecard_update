package com.jzoom.nfc;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.IsoDep;
import android.nfc.tech.TagTechnology;
import android.os.Build;
import android.os.Parcelable;


import java.io.IOException;
import java.lang.reflect.Method;


/**
 * Created by renxueliang on 2017/10/19.
 */

public class NfcModel {

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;

    public static String[][] techLists;
    public static IntentFilter[] filters;

    //技术列表
    private Class<? extends TagTechnology>[] techs;



    private NfcListener listener;


    public NfcModel(Activity activity, Class<? extends TagTechnology>...techs) throws IntentFilter.MalformedMimeTypeException {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD_MR1) {
            techLists =  new String[techs.length][];   // new String[][] { { IsoDep.class.getName() } };
            for(int i=0; i < techs.length; ++i){
                techLists[i] = new String[]{  techs[i].getName()   };
            }
            this.techs = techs;
            filters = new IntentFilter[] { new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED, "*/*") };

            nfcAdapter = NfcAdapter.getDefaultAdapter(activity);
            pendingIntent = PendingIntent.getActivity(activity, 0, new Intent(
                    activity, activity.getClass())
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);


            onNewIntent(activity.getIntent());
        }
    }

    public void onNewIntent(Intent intent){
        Parcelable p = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (p != null) {
            load(p);
        }
    }


    public NfcListener getListener() {
        return listener;
    }

    public void setListener(NfcListener listener) {
        this.listener = listener;
    }

    TagTechnology adapter;


    public void close(){
        if(adapter!=null){
            try {
                adapter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void load(Parcelable parcelable) {
        close();
        final Tag tag = (Tag) parcelable;
        if(listener!=null){
            for(Class<? extends  TagTechnology> t : techs){
                //get
                try {
                    Method method = t.getMethod("get",Tag.class);
                    TagTechnology result = (TagTechnology) method.invoke(null,tag);
                    if(result==null){
                        continue;
                    }
                    adapter = result;
                    listener.onNfcEvent(result);
                } catch (Exception e) {
                    e.printStackTrace();
                 //  throw new RuntimeException(e);
                }

            }
        }
    }


    public void onResume(Activity context) {
        if (nfcAdapter != null) {
            nfcAdapter.enableForegroundDispatch(context, pendingIntent,
                    filters,
                    techLists);
        }
    }

    public void onPause(Activity context) {
        if (nfcAdapter != null) {
            nfcAdapter.disableForegroundDispatch(context);
        }
    }

    public void destroy() {
        nfcAdapter = null;
    }
}
