package com.jzoom.nfc.impl;

import android.nfc.tech.IsoDep;

import com.jzoom.nfc.DepTagAdapter;
import com.jzoom.nfc.HexUtil;
import com.jzoom.nfc.NfcException;
import com.jzoom.nfc.NfcResponse;
import com.jzoom.nfc.NfcTagAdapter;

import java.io.IOException;

/**
 * Created by randy on 2017/1/28.
 */
public class IsoDepTagAdapter implements DepTagAdapter {

    private final IsoDep isoDep;

    public IsoDepTagAdapter(IsoDep isoDep){
        this.isoDep = isoDep;
    }

    @Override
    public NfcResponse send(String adpu) throws IOException, NfcException {
        try{
            return new NfcResponse(isoDep.transceive(HexUtil.decodeHex(adpu))).validate();
        }catch (NfcException e){
            throw  e;
        }catch (IOException e){
            throw  e;
        }
    }

    @Override
    public String[] send(String[] adpus) throws IOException, NfcException {
        String[] arr = new String[adpus.length];
        for(int i=0 , c = adpus.length; i < c; ++i){
            String cmd = adpus[i];
            if(cmd.contains(",")){
                String[] args = cmd.split(",");
                NfcResponse response = null;
                for(String arg : args){
                    response = send(arg);
                }
                //只用最后一个为主
                String result = response.getStr();
                arr[i]= result;
            }else{
                NfcResponse response = send(adpus[i]);
                String result = response.getStr();
                arr[i]= result;
            }
        }

        return arr;
    }


    @Override
    public void connect() throws IOException {
        if(!isoDep.isConnected()){
            isoDep.connect();
        }
    }

    public void close(){
        try {
            isoDep.close();
        } catch (Throwable e) {

        }
    }


    public boolean isConnected() {
        return isoDep.isConnected();

    }
}
