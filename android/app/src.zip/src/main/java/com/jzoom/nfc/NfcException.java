package com.jzoom.nfc;

/**
 * Created by randy on 2017/1/28.
 */

public class NfcException extends Exception {
    private short sw;

    public NfcException(short sw){
        this.sw = sw;
    }


}
