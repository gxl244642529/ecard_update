package com.jzoom.nfc;

import java.io.IOException;

/**
 * Created by randy on 2017/1/28.
 */

public interface NfcTagAdapter {

    /**
     * 连接nfc
     * @throws IOException
     */
    void connect() throws IOException;

    /**
     * 关闭
     */
    void close();

    /**
     * 是否连接
     * @return
     */
    boolean isConnected();
}
