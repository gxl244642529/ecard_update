package com.jzoom.nfc;

import android.content.Context;
import android.nfc.NfcAdapter;
import android.os.Build;

/**
 * Created by renxueliang on 2017/10/20.
 */

public class NfcUtil {

    public static boolean isAvailable(Context context){
        if (android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.GINGERBREAD_MR1) {
            NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(context);
            return nfcAdapter != null;
        }
        return false;
    }
}
