package com.jzoom.nfc;

import java.io.IOException;

/**
 * Created by renxueliang on 2017/10/20.
 */

public interface DepTagAdapter extends  NfcTagAdapter {

    /**
     * 发送指令，并返回数据
     * @param adpu
     * @return
     */
    NfcResponse send(String adpu) throws IOException,NfcException;

    /**
     * 发送指令
     * @param adpus
     * @return
     * @throws IOException
     * @throws NfcException
     */
    String[] send(String[] adpus) throws  IOException,NfcException;

}
