package com.jzoom.nfc;

import android.nfc.Tag;
import android.nfc.tech.TagTechnology;

/**
 * Created by randy on 2017/1/28.
 */

public interface NfcListener {
    /**
     * 贴卡
     * @param tag
     */
    void onNfcEvent(TagTechnology tag);


}
