package com.citywithincity.ecard;

/**
 * Created by renxueliang on 2017/9/13.
 */

public class PinganConfig {
    public static final boolean RELEASE = true;
}
